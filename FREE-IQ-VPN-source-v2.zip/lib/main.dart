import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const FreeIqVpnApp());

const Color bg = Color(0xFF06110E);
const Color panel = Color(0xFF0D2119);
const Color green = Color(0xFF20D879);
const Color muted = Color(0xFFA9B9B0);

class FreeIqVpnApp extends StatefulWidget {
  const FreeIqVpnApp({super.key});
  @override
  State<FreeIqVpnApp> createState() => _FreeIqVpnAppState();
}

class _FreeIqVpnAppState extends State<FreeIqVpnApp> {
  String language = 'ar';
  int page = 0;

  bool get rtl => language == 'ar';
  String t(String key) => (strings[language] ?? strings['en']!)[key] ?? key;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FREE IQ VPN',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: Directionality(
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: bg,
            elevation: 0,
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: Image.asset('assets/irq_vpn_logo.png', width: 38, height: 38, fit: BoxFit.cover),
                ),
                const SizedBox(width: 10),
                const Text('FREE IQ VPN', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.1)),
              ],
            ),
            actions: [
              IconButton(
                tooltip: t('settings'),
                onPressed: () => setState(() => page = 2),
                icon: const Icon(Icons.settings_outlined, color: green),
              ),
            ],
          ),
          body: SafeArea(child: _pageBody()),
          bottomNavigationBar: NavigationBar(
            backgroundColor: const Color(0xFF091A13),
            indicatorColor: green.withOpacity(.16),
            selectedIndex: page,
            onDestinationSelected: (v) => setState(() => page = v),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.shield_outlined), selectedIcon: const Icon(Icons.shield, color: green), label: t('home')),
              NavigationDestination(icon: const Icon(Icons.people_outline), selectedIcon: const Icon(Icons.people, color: green), label: t('follow')),
              NavigationDestination(icon: const Icon(Icons.tune), selectedIcon: const Icon(Icons.tune, color: green), label: t('settings')),
              NavigationDestination(icon: const Icon(Icons.info_outline), selectedIcon: const Icon(Icons.info, color: green), label: t('about')),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pageBody() {
    switch (page) {
      case 1: return _followPage();
      case 2: return _settingsPage();
      case 3: return _aboutPage();
      default: return _homePage();
    }
  }

  Widget _homePage() => ListView(
    padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF10291D), Color(0xFF091811)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: green.withOpacity(.25)),
        ),
        child: Column(children: [
          ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/irq_vpn_logo.png', width: 190, height: 190, fit: BoxFit.contain)),
          const SizedBox(height: 14),
          Text(t('welcome'), style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(t('tagline'), style: const TextStyle(color: muted, fontSize: 14), textAlign: TextAlign.center),
        ]),
      ),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(26), border: Border.all(color: green.withOpacity(.35))),
        child: Column(children: [
          Text(t('connection'), style: const TextStyle(color: muted, fontSize: 16)),
          const SizedBox(height: 12),
          Text(t('notConnected'), style: const TextStyle(color: Color(0xFFFFC76A), fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          Container(
            width: 142, height: 142,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: const LinearGradient(colors: [Color(0xFF20D879), Color(0xFF087C49)]), boxShadow: [BoxShadow(color: green.withOpacity(.2), blurRadius: 28, spreadRadius: 3)]),
            child: const Icon(Icons.power_settings_new, size: 76, color: Colors.white),
          ),
          const SizedBox(height: 18),
          Text(t('previewNote'), textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFD9C58B), height: 1.5)),
        ]),
      ),
      const SizedBox(height: 16),
      _infoTile(Icons.flag_outlined, t('iraqTitle'), t('iraqText')),
      _infoTile(Icons.lock_outline, t('privacyTitle'), t('privacyText')),
    ],
  );

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(20), children: [
    _sectionTitle(t('settings')),
    const SizedBox(height: 14),
    _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(t('language'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...[
        ('ar', 'العربية'), ('en', 'English'), ('tr', 'Türkçe'), ('ru', 'Русский'),
      ].map((item) => RadioListTile<String>(
        value: item.$1, groupValue: language, activeColor: green, contentPadding: EdgeInsets.zero,
        title: Text(item.$2), onChanged: (v) => setState(() => language = v!),
      )),
    ])),
    const SizedBox(height: 14),
    _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(t('features'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      _bullet(t('feature1')), _bullet(t('feature2')), _bullet(t('feature3')), _bullet(t('feature4')),
    ])),
    const SizedBox(height: 14),
    _panel(child: Row(children: [const Icon(Icons.campaign_outlined, color: green), const SizedBox(width: 10), Expanded(child: Text(t('freeNotice'), style: const TextStyle(color: muted)))])),
  ]);

  Widget _followPage() => ListView(padding: const EdgeInsets.all(20), children: [
    _sectionTitle(t('follow')),
    const SizedBox(height: 8),
    Text(t('followText'), style: const TextStyle(color: muted)),
    const SizedBox(height: 18),
    _socialButton(Icons.camera_alt_outlined, 'Instagram', '@bgq_v', 'https://www.instagram.com/bgq_v?obrf=eTZ2eTVzbTFqOTN2'),
    const SizedBox(height: 10),
    _socialButton(Icons.facebook, 'Facebook', t('facebookLabel'), 'https://www.facebook.com/share/1GDSCKqHGJ/'),
    const SizedBox(height: 10),
    _socialButton(Icons.send_rounded, 'Telegram', '@bgq_v', 'https://t.me/bgq_v'),
    const SizedBox(height: 20),
    _panel(child: Column(children: [
      Text(t('telegramQr'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      const SizedBox(height: 12),
      ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset('assets/telegram_qr.png', width: 230, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.qr_code, size: 100, color: green))),
      const SizedBox(height: 8),
      const Text('@bgq_v', style: TextStyle(color: green, fontWeight: FontWeight.bold)),
    ])),
  ]);

  Widget _aboutPage() => ListView(padding: const EdgeInsets.all(20), children: [
    _sectionTitle(t('about')),
    const SizedBox(height: 16),
    _panel(child: Column(children: [
      Image.asset('assets/irq_vpn_logo.png', width: 150, height: 150, fit: BoxFit.contain),
      const SizedBox(height: 12),
      const Text('FREE IQ VPN', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1)),
      const SizedBox(height: 8),
      Text(t('aboutDescription'), textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.6)),
      const Divider(height: 28, color: Color(0xFF284438)),
      Text(t('developer'), style: const TextStyle(color: muted)),
      const SizedBox(height: 5),
      const Text('حسين البياتي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: green)),
      const SizedBox(height: 12),
      Text(t('versionLabel'), style: const TextStyle(color: muted)),
      const Text('1.0.0'),
    ])),
    const SizedBox(height: 14),
    _panel(child: Text(t('honestStatus'), style: const TextStyle(color: Color(0xFFFFD28A), height: 1.5))),
  ]);

  Widget _sectionTitle(String text) => Text(text, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800));
  Widget _panel({required Widget child}) => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: green.withOpacity(.2))), child: child);
  Widget _infoTile(IconData icon, String title, String body) => Container(margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: Row(children: [Icon(icon, color: green), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(body, style: const TextStyle(color: muted))]))]));
  Widget _bullet(String text) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.check_circle_outline, color: green, size: 18), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(color: muted)))]));
  Widget _socialButton(IconData icon, String name, String handle, String url) {
    final Color brandColor = name == 'Instagram'
        ? const Color(0xFFE85AA8)
        : name == 'Facebook'
            ? const Color(0xFF2787F5)
            : const Color(0xFF35BDEB);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () async {
          final uri = Uri.parse(url);
          try {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          } catch (_) {
            await launchUrl(uri, mode: LaunchMode.platformDefault);
          }
        },
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: panel,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: brandColor.withOpacity(.42)),
            boxShadow: [BoxShadow(color: brandColor.withOpacity(.07), blurRadius: 18, spreadRadius: 1)],
          ),
          child: Row(children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                color: brandColor.withOpacity(.14),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(icon, color: brandColor, size: 27),
            ),
            const SizedBox(width: 13),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: TextStyle(fontWeight: FontWeight.bold, color: brandColor, fontSize: 16)),
                Text(handle, style: const TextStyle(color: muted, fontSize: 13)),
                const SizedBox(height: 3),
                Text(t('openProfile'), style: TextStyle(color: brandColor.withOpacity(.9), fontSize: 11)),
              ],
            )),
            Icon(Icons.open_in_new_rounded, color: brandColor, size: 20),
          ]),
        ),
      ),
    );
  }
}

const Map<String, Map<String, String>> strings = {
'ar': {
'home':'الرئيسية','follow':'تابعونا','settings':'الإعدادات','about':'حول التطبيق','welcome':'مرحباً بك في FREE IQ VPN','tagline':'هوية عراقية • رؤية عالمية','connection':'حالة الاتصال','notConnected':'غير متصل','previewNote':'هذه واجهة تجريبية حالياً — الاتصال الحقيقي سيُضاف بعد تجهيز خوادم VPN وربطها بأمان.','iraqTitle':'صُنع بروح عراقية','iraqText':'مشروع مستقل بفخر واعتزاز بالعراق.','privacyTitle':'الخصوصية أولاً','privacyText':'لن ندّعي وجود حماية VPN فعلية قبل تشغيل الاتصال واختباره.','language':'لغة التطبيق','features':'مميزات التطبيق','feature1':'واجهة هادئة وسهلة الاستخدام.','feature2':'دعم العربية والإنجليزية والتركية والروسية.','feature3':'روابط مباشرة لحسابات المطور.','feature4':'مجاني بالكامل وبدون إعلانات.','freeNotice':'FREE IQ VPN مجاني بالكامل، بلا إعلانات أو اشتراكات.','followText':'يسعدنا تواصلكم ومتابعتكم لحسابات المطور.','facebookLabel':'صفحتنا على فيسبوك','openProfile':'اضغط لفتح الحساب','telegramQr':'امسح الرمز لزيارة تيليجرام','aboutDescription':'تطبيق بهوية عراقية يهدف إلى تقديم تجربة بسيطة وهادئة، مع التركيز على الوضوح والخصوصية.','developer':'المطور','versionLabel':'الإصدار','honestStatus':'تنبيه: هذه النسخة تحتوي على الواجهة فقط. لم يتم تفعيل نفق VPN حقيقي بعد. لن يظهر التطبيق على أنه متصل قبل تنفيذ الاتصال الحقيقي واختباره.'},
'en': {
'home':'Home','follow':'Follow us','settings':'Settings','about':'About','welcome':'Welcome to FREE IQ VPN','tagline':'Iraqi identity • Global vision','connection':'Connection status','notConnected':'Not connected','previewNote':'This is currently a preview interface. Real VPN connectivity will be added after secure server setup and integration.','iraqTitle':'Made with Iraqi pride','iraqText':'An independent project created with pride in Iraq.','privacyTitle':'Privacy first','privacyText':'We will not claim VPN protection until a real connection is implemented and tested.','language':'App language','features':'App features','feature1':'Calm and easy-to-use interface.','feature2':'Arabic, English, Turkish and Russian support.','feature3':'Direct links to the developer social accounts.','feature4':'Completely free with no ads.','freeNotice':'FREE IQ VPN is completely free, with no ads or subscriptions.','followText':'We would be happy to connect with you on the developer social accounts.','facebookLabel':'Our Facebook page','openProfile':'Tap to open profile','telegramQr':'Scan to visit Telegram','aboutDescription':'An app with an Iraqi identity, aiming to offer a simple and calm experience with a focus on clarity and privacy.','developer':'Developer','versionLabel':'Version','honestStatus':'Notice: This version currently contains the interface only. A real VPN tunnel has not been enabled yet. The app will not show as connected until real connectivity is implemented and tested.'},
 'tr': {
'home':'Ana sayfa','follow':'Bizi takip edin','settings':'Ayarlar','about':'Hakkında','welcome':'FREE IQ VPN uygulamasına hoş geldiniz','tagline':'Irak kimliği • Küresel vizyon','connection':'Bağlantı durumu','notConnected':'Bağlı değil','previewNote':'Bu şu anda bir önizleme arayüzüdür. Gerçek VPN bağlantısı, güvenli sunucular hazırlandıktan sonra eklenecektir.','iraqTitle':'Irak gururuyla hazırlandı','iraqText':'Irak sevgisiyle geliştirilmiş bağımsız bir proje.','privacyTitle':'Önce gizlilik','privacyText':'Gerçek bağlantı uygulanıp test edilmeden VPN koruması iddia edilmeyecektir.','language':'Uygulama dili','features':'Uygulama özellikleri','feature1':'Sade ve kullanımı kolay arayüz.','feature2':'Arapça, İngilizce, Türkçe ve Rusça desteği.','feature3':'Geliştiricinin sosyal hesaplarına doğrudan bağlantılar.','feature4':'Tamamen ücretsiz, reklamsız.','freeNotice':'FREE IQ VPN tamamen ücretsizdir; reklam ve abonelik yoktur.','followText':'Geliştiricinin sosyal hesaplarından bize ulaşabilirsiniz.','facebookLabel':'Facebook sayfamız','openProfile':'Profili açmak için dokunun','telegramQr':'Telegram için QR kodunu tarayın','aboutDescription':'Irak kimliğine sahip, sadelik ve gizliliğe odaklanan bir uygulama.','developer':'Geliştirici','versionLabel':'Sürüm','honestStatus':'Not: Bu sürüm yalnızca arayüzü içerir. Gerçek VPN bağlantısı henüz etkin değildir. Gerçek bağlantı uygulanıp test edilmeden uygulama bağlı göstermeyecektir.'},
'ru': {
'home':'Главная','follow':'Мы в сети','settings':'Настройки','about':'О приложении','welcome':'Добро пожаловать в FREE IQ VPN','tagline':'Иракская идентичность • Глобальный взгляд','connection':'Состояние подключения','notConnected':'Не подключено','previewNote':'Сейчас это демонстрационный интерфейс. Реальное VPN-подключение будет добавлено после настройки защищённых серверов.','iraqTitle':'Создано с гордостью за Ирак','iraqText':'Независимый проект, созданный с любовью к Ираку.','privacyTitle':'Конфиденциальность прежде всего','privacyText':'Мы не будем заявлять о VPN-защите, пока реальное подключение не будет реализовано и проверено.','language':'Язык приложения','features':'Возможности приложения','feature1':'Спокойный и простой интерфейс.','feature2':'Поддержка арабского, английского, турецкого и русского языков.','feature3':'Прямые ссылки на социальные сети разработчика.','feature4':'Полностью бесплатно и без рекламы.','freeNotice':'FREE IQ VPN полностью бесплатен, без рекламы и подписок.','followText':'Будем рады видеть вас в социальных сетях разработчика.','facebookLabel':'Наша страница Facebook','openProfile':'Нажмите, чтобы открыть профиль','telegramQr':'Отсканируйте QR-код для Telegram','aboutDescription':'Приложение с иракской идентичностью, созданное для простоты, спокойствия и ясности.','developer':'Разработчик','versionLabel':'Версия','honestStatus':'Внимание: эта версия содержит только интерфейс. Реальный VPN-туннель пока не включён. Приложение не будет показывать подключение до реализации и проверки реального соединения.'},
};
