# FREE IQ VPN

An Arabic-first Flutter app interface celebrating Iraq, with Arabic, English, Turkish and Russian UI, app information, settings and social links.

## Important status
This source currently contains the app interface only. It does **not** yet establish a VPN tunnel or protect network traffic. A real VPN requires a properly configured VPN protocol (such as WireGuard), secure server infrastructure, key management, privacy/security testing and Android VPN integration. The connect control is intentionally presented as a preview until that work is completed.

## Assets
- `assets/irq_vpn_logo.png` — official app logo and launcher icon source.
- `assets/telegram_qr.png` — Telegram QR image supplied by the developer.

Developer: Hussein Al-Bayati (حسين البياتي)
