import 'package:flutter/material.dart';

void main() {
  runApp(const IRQVpnApp());
}

class IRQVpnApp extends StatelessWidget {
  const IRQVpnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IRQ VPN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07110D),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF18D66B),
          secondary: Color(0xFF8CFFB5),
          surface: Color(0xFF102019),
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF123523),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: const Color(0xFF1B9C55)),
                    ),
                    child: const Icon(Icons.shield_moon_outlined,
                        color: Color(0xFF58F293), size: 28),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('IRQ VPN',
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.1)),
                      Text('اتصال آمن • بهوية عراقية',
                          style: TextStyle(
                              color: Color(0xFF9BB5A5), fontSize: 12)),
                    ],
                  ),
                  const Spacer(),
                  const Icon(Icons.more_vert, color: Color(0xFFB9C9BF)),
                ],
              ),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFF0D1B14),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFF1B3C2A)),
                ),
                child: Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.asset(
                        'assets/irq_vpn_logo.png',
                        height: 210,
                        width: double.infinity,
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text('مرحباً بك في IRQ VPN',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    const Text(
                      'حماية اتصالك تبدأ من هنا',
                      style: TextStyle(color: Color(0xFF9BB5A5)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 26),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 18),
                decoration: BoxDecoration(
                  color: const Color(0xFF10251A),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFF205B37)),
                ),
                child: Column(
                  children: [
                    const Text('حالة الاتصال',
                        style: TextStyle(
                            color: Color(0xFFB6C9BC), fontSize: 14)),
                    const SizedBox(height: 10),
                    const Text('غير متصل',
                        style: TextStyle(
                            color: Color(0xFFFFC66D),
                            fontSize: 25,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 18),
                    Container(
                      width: 154,
                      height: 154,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [Color(0xFF1FE477), Color(0xFF087A3B)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF18D66B).withOpacity(0.25),
                            blurRadius: 30,
                            spreadRadius: 4,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.power_settings_new,
                          size: 72, color: Colors.white),
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      'واجهة تجريبية حالياً — الاتصال الحقيقي سيُضاف في المرحلة التالية',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Color(0xFFFFD58C),
                          fontSize: 12,
                          height: 1.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF101B16),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFF24392C)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.public, color: Color(0xFF58F293), size: 28),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('موقع الخادم',
                              style: TextStyle(
                                  color: Color(0xFF9BB5A5), fontSize: 12)),
                          SizedBox(height: 4),
                          Text('سيتم اختيار الدولة بعد تجهيز الخوادم',
                              style: TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                    Icon(Icons.chevron_left, color: Color(0xFF8CA394)),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Center(
                child: Text(
                  'IRQ VPN  •  الإصدار الأولي',
                  style: TextStyle(color: Color(0xFF6F8878), fontSize: 11),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
